=============
Version 4.6.2
=============

Version 4.6.2 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.6.2

Bugs Fixed
----------

* Full details of error not logged when a Python script file could not be
  loaded due to a failure when parsing Python code.
